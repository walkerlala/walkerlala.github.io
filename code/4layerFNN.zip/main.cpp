#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cctype>
#include <algorithm>
#include "./4layerFNN.hpp"

using std::cout;
using std::endl;
using std::vector;
using std::string;

//some util function
int usage() {
    cout << "usage:" << endl;
    cout << "\tprogram data_file label" << endl;
    return 0;
}

vector<double> split(string &str, char delim = ',') {
    vector<double> elems;
    std::stringstream ss;
    ss.str(str);
    string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(atof(item.c_str()));
    }
    return elems;
}

bool isemptyline(string& s) {
	for (auto& c : s) {
		if (!std::isspace(c)) {
			return false;
		}
	}
	return true;
}

int minmaxmap(vector<double> vec) {
	double mx = *std::max_element(vec.begin(), vec.end());
	double mn = *std::min_element(vec.begin(),vec.end());
	for(auto& elem : vec) {
		elem = (elem - mn) / (mx - mn);
	}
	return 1;
}

/* Note: every line in the input file should be seperated by comma
*/
int main(int args, char **argv) {
	
    if (args != 3) {
        cout << "invalid args" << endl;
        usage();
        return -1;
    }

    std::ifstream data_file(argv[1]);
	std::ifstream label_file(argv[2]);
    string line;
	vector<vector<double>> total;
	vector<double> labels_total;
	while (data_file >> line) {
		if (!isemptyline(line)) {
			vector<double> t = split(line);
			total.push_back(split(line));
		}
	}
	while (label_file >> line) {
		if (!isemptyline(line)) {
			labels_total.push_back(atof(line.c_str()));
		}
		minmaxmap(labels_total);
	}
	if (labels_total.size() != total.size()) {
		cout << "data size mismatch label size. Aborted." << endl;
		return -1;
	}

	//start 10-fold cross validation
	int piecesize = labels_total.size() / 10;
	if (piecesize <= 0) {
		cout << "Too little input! Aborted." << endl;
		return -1;
	}
	vector<double> accs;
	for (int i = 0;i < 10;i++) {
		Matrix<double> validate_dataSet;
		vector<double> validate_label;
		Matrix<double> dataSet;
		vector<double> label;

		//fill validation set
		for (int j = i*piecesize;j < (i + 1)*piecesize;j++) {
			validate_dataSet.inject_row(total[j]);
			validate_label.push_back(labels_total[j]);
		}
		for (int j = 0;j < i*piecesize;j++) {
			dataSet.inject_row(total[j]);
			label.push_back(labels_total[j]);
		}
		for (int j = (i + 1)*piecesize;j < labels_total.size();j++) {
			dataSet.inject_row(total[j]);
			label.push_back(labels_total[j]);
		}

		FourLayerFNN myFNN(dataSet.columns(), 25, 23, 0.0001, 0.01, 1000);

		myFNN.trainFNN(dataSet, label);
		vector<double> preds = myFNN.predict(validate_dataSet);

		int hit = 0;
		for (int i = 0;i < preds.size();i++) {
			cout << "Pred: " << preds[i] << "\t" << "small_labels: " << validate_label[i] << "\t";
			if (fabs(preds[i] - validate_label[i]) < 0.5) {
				cout << "HIT";
				hit++;
			}
			cout << endl;
		}
		double acc = (double)hit / validate_dataSet.rows();
		accs.push_back(acc);
		cout << "Fold"<<i<<": hit: " << hit << "\t acc: " << acc << endl;
		
		//cout << "Parameter: " << endl;
	}

	double sum = 0;
	cout << "\naccs: " << endl; 
	for (auto a : accs) {
		cout << a << endl;
		sum += a;
	}
	cout << "\naverage accs: " << sum / 10 << endl;
	
    return 0;
}
